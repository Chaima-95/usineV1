/** @format */

const mongoose = require("mongoose");
const Production = mongoose.model(
  "Production",
  new mongoose.Schema(
    {
      personnels: [
        {
          type: mongoose.Schema.Types.Object,
          ref: "Personnel",
        },
      ],
      productName: {
        type: String,
        trim: true,
      },
      hour: {
        type: String,
        // required: true,
        trim: true,
      },
      date: {
        type: String,
        // required: true,
        trim: true,
      },
      nbrOfPiecesProduicedInHour: {
        type: Number,
        // required: true,
        trim: true,
      },
      nbrOfNonConformPieces: {
        type: Number,
        // required: true,
        trim: true,
      },
      nbrOfPersons: {
        type: Number,
        // required: true,
        trim: true,
      },
      comment: {
        type: String,
        // required: true,
        trim: true,
      },
      alea: {
        type: mongoose.Schema.Types.Object,
        ref: "Alea",
      },
    },
    { timestamps: true }
  )
);

module.exports = Production;
