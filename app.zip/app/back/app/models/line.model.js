/** @format */
const mongoose = require("mongoose");
const Line = mongoose.model(
  "Line",
  new mongoose.Schema(
    {
      name: {
        type: String,
        required: true,
        trim: true,
      },
      product: {
        type: mongoose.Schema.Types.Object,
        ref: "Product",
      },
    },
    { timestamps: true }
  )
);
module.exports = Line;
