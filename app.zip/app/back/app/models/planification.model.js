/** @format */

const mongoose = require("mongoose");
const Planification = mongoose.model(
  "Planification",
  new mongoose.Schema(
    {
      lines: [
        {
          type: mongoose.Schema.Types.Object,
          ref: "Line",
        },
      ],
      zone: {
        type: mongoose.Schema.Types.Object,
        ref: "Zone",
      },
      productions: [
        {
          type: mongoose.Schema.Types.Object,
          ref: "Production",
        },
      ],
    },

    { timestamps: true }
  )
);

module.exports = Planification;
