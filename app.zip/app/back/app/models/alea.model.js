/** @format */

const mongoose = require("mongoose");
const Alea = mongoose.model(
  "Alea",
  new mongoose.Schema(
    {
      name: {
        type: String,
        required: true,
        trim: true,
      },
    },
    { timestamps: true }
  )
);

module.exports = Alea;
