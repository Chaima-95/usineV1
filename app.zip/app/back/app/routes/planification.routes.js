/** @format */
module.exports = (app) => {
  const planification = require("../controllers/planification.controller.js");
  var route = require("express").Router();

  route.post("/create", planification.create);
  route.get("/getall", planification.getall);
  route.get("/getbyid/:id", planification.getbyid);
  route.get("/getbyname", planification.getbyname);
  route.put("/update/:id", planification.update);
  route.delete("/delete/:id", planification.delete);
  app.use("/api/planification", route);
};
