/** @format */
module.exports = (app) => {
  const alea = require("../controllers/alea.controller.js");
  var route = require("express").Router();

  route.post("/create", alea.create);
  route.get("/getall", alea.getall);
  route.get("/getbyid/:id", alea.getbyid);
  route.get("/getbyname", alea.getbyname);
  route.put("/update/:id", alea.update);
  route.delete("/delete/:id", alea.delete);
  app.use("/api/alea", route);
};
