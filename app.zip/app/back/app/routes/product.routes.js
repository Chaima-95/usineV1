/** @format */
module.exports = (app) => {
  const product = require("../controllers/product.controller.js");
  var route = require("express").Router();

  route.post("/create", product.create);
  route.get("/getall", product.getall);
  route.get("/getbyid/:id", product.getbyid);
  route.get("/getbyname", product.getbyname);
  route.put("/update/:id", product.update);
  route.delete("/delete/:id", product.delete);
  app.use("/api/product", route);
};
