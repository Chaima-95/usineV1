/** @format */
module.exports = (app) => {
  const hourSystem = require("../controllers/hourSystem.controller.js");
  var route = require("express").Router();

  route.post("/create", hourSystem.create);
  route.get("/getall", hourSystem.getall);
  route.get("/getbyid/:id", hourSystem.getbyid);
  route.get("/getbyname", hourSystem.getbyname);
  route.put("/update/:id", hourSystem.update);
  route.delete("/delete/:id", hourSystem.delete);
  app.use("/api/hourSystem", route);
};
