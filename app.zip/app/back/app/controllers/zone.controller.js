/** @format */

const zoneModel = require("../models/zone.model");
module.exports = {
  create: async (req, res) => {
    const zone = new zoneModel(req.body);
    await zone.save(req.body, (err, zone) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created zone",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "zone Added successufly",
          data: zone,
        });
      }
    });
  },
  getall: async (req, res) => {
    let query = {};
    if (req.query.searchQuery) {
      query.name = {
        $regex: new RegExp("^" + req.query.searchQuery.trim() + ".*", "i"),
      };
    }
    await zoneModel.find(query).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get all zones" });
      } else {
        res.status(201).json({
          success: true,
          message: "List of zones",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await zoneModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res.status(406).json({ success: false, message: "Failed to get zone" });
      } else {
        res.status(201).json({ success: true, message: "zone", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await zoneModel.find({ name: req.query.name }).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get  zone by this name",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of zones",
          data: items,
        });
      }
    });
  },
  update: async (req, res) => {
    await zoneModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res
            .status(406)
            .json({ success: false, message: "Failed to update zone" });
        } else {
          res.status(201).json({
            success: true,
            message: "zone updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await zoneModel.findByIdAndRemove(req.params.id).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to deleted zone" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "zone deleted successfuly" });
      }
    });
  },
};
