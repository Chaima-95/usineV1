/** @format */

const personnelModel = require("../models/personnel.model");
const db = require("../models");
const Personnel = db.personnel;
const Zone = db.zone;
module.exports = {
  create: async (req, res) => {
    const personnel = new personnelModel(req.body);
    // console.log(req.body);
    await personnel.save(req.body, (err, personnel) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created personnel",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "personnel Added successufly",
          data: personnel,
        });
      }
    });
  },

  getall: async (req, res) => {
    let query = {};
    if (req.query.searchQuery) {
      query.name = {
        $regex: new RegExp("^" + req.query.searchQuery.trim() + ".*", "i"),
      };
    }
    await personnelModel.find(query).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get all personnels",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of personnels",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await personnelModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get personnel" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "personnel", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await personnelModel.find({ name: req.query.name }).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get  personnel by this name",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of personnels",
          data: items,
        });
      }
    });
  },
  update: async (req, res) => {
    await personnelModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res.status(406).json({
            success: false,
            message: "Failed to update personnel",
          });
        } else {
          res.status(201).json({
            success: true,
            message: "personnel updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await personnelModel.findByIdAndRemove(req.params.id).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to deleted personnel",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "personnel deleted successfuly",
        });
      }
    });
  },
};
