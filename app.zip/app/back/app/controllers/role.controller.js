/** @format */

const db = require("../models");
const Role = db.role;

// Find a single role with an id
exports.findOne = (req, res) => {
  const id = req.params.id;
  Role.findById(id)
    .then((data) => {
      if (!data)
        res.status(404).send({ message: "Not found Role with id " + id });
      else res.send(data);
    })
    .catch((err) => {
      res.status(500).send({ message: "Error retrieving Role with id=" + id });
    });
};

exports.findAll = (req, res) => {
  const name = req.query.name;
  var condition = name
    ? { name: { $regex: new RegExp(name), $options: "i" } }
    : {};
  Role.find(condition)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving roles.",
      });
    });
};
