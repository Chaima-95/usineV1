/** @format */

import { InputNumber } from "antd";
import React from "react";

const Input = ({ onChangeInput, inputValue }) => {
  return (
    <InputNumber
      onChange={onChangeInput}
      value={inputValue}
      // style={{
      //   width: 200,
      // }}
      // defaultValue='0'
      // min='0'
      // step='1'
    />
  );
};

export default Input;
