/** @format */

import MaterialTable from "@material-table/core";
import React, { useEffect, useRef, useState } from "react";
import productData from "../../../services/product.service";
import isEmail from "validator/lib/isEmail";

const Products = () => {
  const [iserror, setIserror] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [columns, setColumns] = useState([
    { title: "Code Product", field: "code" },
    { title: "Name Product", field: "name" },
    { title: "Production in hour", field: "productionInHour" },
    { title: "Phase Product", field: "phase.name" },
  ]);
  const [products, setProducts] = useState([]);
  const productsRef = useRef();
  productsRef.current = products;

  // ************ delete user *********** //
  const deleteProduct = (oldData, resolve) => {
    productData
      .remove(oldData._id)
      .then((res) => {
        const index = oldData.tableData.id;
        let newProducts = [...productsRef.current];
        newProducts.splice(index, 1);
        setProducts(newProducts);
        resolve();
      })
      .catch((e) => {
        console.log(e);
        resolve();
      });
  };
  useEffect(() => {
    productData
      .getAll()
      .then((response) => {
        setProducts(response.data.data);
        console.log(response.data.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }, []);

  // ************ add article *********** //
  const addProducts = (newData, resolve) => {
    console.log(newData);
    productData
      .add(newData)
      .then((res) => {
        const updatedRows = [...productsRef.current, { ...newData }];
        setProducts(updatedRows);
        resolve();
      })
      .catch((e) => {
        console.log(e);
        resolve();
      });
  };

  // ************ update user *********** //
  const updateProduct = (newData, oldData, resolve) => {
    //validation
    let errorList = [];
    // if (newData.email === undefined || !isEmail(newData.email) === false) {
    //   errorList.push("Please enter a valid email");
    // }

    // if (
    //   newData.productionInHour === undefined ||
    //   !newData.productionInHour === false
    // ) {
    //   errorList.push("Please enter a valid nbr");
    //   console.log("error");
    // }
    if (errorList.length < 1) {
      productData
        .update(newData._id, newData)
        .then((res) => {
          const dataUpdate = [...productsRef.current];
          const index = oldData.tableData.id;
          dataUpdate[index] = newData;
          setProducts([...dataUpdate]);
          resolve();
          setIserror(false);
          setErrorMessages([]);
        })
        .catch((error) => {
          setErrorMessages(["Update failed! Server error"]);
          setIserror(true);
          resolve();
        });
    } else {
      setErrorMessages(errorList);
      setIserror(true);
      resolve();
    }
  };

  return (
    <MaterialTable
      title=' '
      columns={columns}
      data={products}
      editable={{
        onRowAdd: (newData) =>
          new Promise((resolve, reject) => {
            addProducts(newData, resolve);
          }),
        onRowDelete: (oldData) =>
          new Promise((resolve) => {
            deleteProduct(oldData, resolve);
          }),
        onRowUpdate: (newData, oldData) =>
          new Promise((resolve) => {
            updateProduct(newData, oldData, resolve);
          }),
      }}
    />
  );
};

export default Products;
