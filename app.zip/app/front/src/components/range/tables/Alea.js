/** @format */

import MaterialTable from "@material-table/core";
import React, { useEffect, useRef, useState } from "react";
import aleaData from "../../../services/alea.service";

const Alea = () => {
  const [aleaCol, setAleaCol] = useState([
    { title: " Name Alea", field: "name" },
  ]);
  const [iserror, setIserror] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [aleas, setAleas] = useState([]);
  const aleasRef = useRef();
  aleasRef.current = aleas;

  const getAll = () => {
    aleaData
      .getAll()
      .then((response) => {
        setAleas(response.data.data);
        console.log(response.data.data);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  useEffect(() => {
    getAll();
  }, []);

  // ************ add article *********** //
  const addAlea = (newData, resolve) => {
    console.log(newData);
    aleaData
      .add(newData)
      .then((res) => {
        const updatedRows = [...aleas, { ...newData }];
        setAleas(updatedRows);
        resolve();
      })
      .catch((e) => {
        console.log(e);
        resolve();
      });
  };

  // ************ delete user *********** //
  const deleteAlea = (oldData, resolve) => {
    aleaData
      .remove(oldData._id)
      .then((res) => {
        const index = oldData.tableData.id;
        let newAleas = [...aleas];
        newAleas.splice(index, 1);
        setAleas(newAleas);
        resolve();
      })
      .catch((e) => {
        console.log(e);
        resolve();
      });
  };

  // ************ update user *********** //
  const updateAlea = (newData, oldData, resolve) => {
    //validation
    let errorList = [];
    // if (newData.email === undefined || !isEmail(newData.email) === false) {
    //   errorList.push("Please enter a valid email");
    // }

    // if (newData.personnelNbr === undefined || !newData.personnelNbr === false) {
    //   errorList.push("Please enter a nbr");
    //   console.log("error");
    // }
    if (errorList.length < 1) {
      aleaData
        .update(newData._id, newData)
        .then((res) => {
          const dataUpdate = [...aleas];
          const index = oldData.tableData.id;
          dataUpdate[index] = newData;
          setAleas([...dataUpdate]);
          resolve();
          setIserror(false);
          setErrorMessages([]);
        })
        .catch((error) => {
          setErrorMessages(["Update failed! Server error"]);
          setIserror(true);
          resolve();
        });
    } else {
      setErrorMessages(errorList);
      setIserror(true);
      resolve();
    }
  };
  return (
    <MaterialTable
      title=' '
      columns={aleaCol}
      data={aleas}
      editable={{
        onRowAdd: (newData) =>
          new Promise((resolve) => {
            addAlea(newData, resolve);
          }),
        onRowDelete: (oldData) =>
          new Promise((resolve) => deleteAlea(oldData, resolve)),
        onRowUpdate: (newData, oldData) =>
          new Promise((resolve) => {
            updateAlea(newData, oldData, resolve);
          }),
      }}
    />
  );
};

export default Alea;
