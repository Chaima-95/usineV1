/** @format */

import React, { useRef, useState } from "react";
import objectifData from "../../services/objectifs.service";
import Input from "./Input";

const Objectifs = () => {
  const [eeo, setEeo] = useState("");
  const [trs, setTrs] = useState("");
  const [tap, setTap] = useState("");
  const [message, setMessage] = useState("");
  const [successful, setSuccessful] = useState("");
  const [objectifs, setObjectifs] = useState([]);
  const objectifsRef = useRef();
  objectifsRef.current = objectifs;
  const handleSubmit = () => {
    objectifData.add({ eeo, trs, tap }).then(
      (response) => {
        setMessage(response.data.message);
        setSuccessful(true);
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setMessage(resMessage);
        setSuccessful(false);
      }
    );
  };

  return (
    <div className='EEO_container'>
      <div className='row'>
        <div className='col-md'>
          <label style={{ fontWeight: "500" }}>EEO</label>
          <input
            className='form-control'
            min={0}
            type='number'
            value={eeo}
            onChange={(e) => setEeo(e.target.value)}
          />
        </div>
        <div className='col-md'>
          <label style={{ fontWeight: "500" }}>TRS</label>
          <input
            min={0}
            className='form-control'
            type='number'
            onChange={(e) => setTrs(e.target.value)}
            value={trs}
          />
        </div>
        <div className='col-md'>
          <label style={{ fontWeight: "500" }}>TAP</label>
          <input
            min={0}
            className='form-control'
            type='number'
            onChange={(e) => setTap(e.target.value)}
            value={tap}
            name='tap'
          />
        </div>
        <div className='col-md'>
          <button
            onClick={() => handleSubmit()}
            className='btn btn-primary range_button '>
            Save objectifs
          </button>
        </div>
        <div className='message'>{message ? <p>{message}</p> : null}</div>
      </div>
    </div>
  );
};

export default Objectifs;
