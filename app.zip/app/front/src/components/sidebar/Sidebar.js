/** @format */
import React, { useState, useEffect } from "react";
 
  
import EventBus from "../../common/EventBus";
 
import "./Sidebar.css";
import logo from "../../assets/horlogo.png";
import { Link } from "react-router-dom";
import authService from "../../services/auth.service";

const Sidebar = ({ sidebarOpen, closeSidebar }) => {
  const [showSuperadminBoard, setShowSuperadminBoard] = useState(false);
  const [showAdminBoard, setShowAdminBoard] = useState(false);

  const [currentUser, setCurrentUser] = useState(undefined);
 
   useEffect(() => {
     const user = authService.getCurrentUser();

     if (user) {
       setCurrentUser(user);
       setShowSuperadminBoard(user.roles.includes("ROLE_SUPERADMIN"));
       setShowAdminBoard(user.roles.includes("ROLE_ADMIN"));
     }

     EventBus.on("logout", () => {
       logOut();
     });

     return () => {
       EventBus.remove("logout");
     };
   }, []);
 

  const logOut = () => {
    authService.logout();
    setShowSuperadminBoard(false);
    setShowAdminBoard(false);
    setCurrentUser(undefined);
  };

 

  return (
    <div className={sidebarOpen ? "sidebar_responsive" : ""} id='sidebar'>
      <div className='sidebar__title'>
        <Link to='/'>
          <img src={logo} alt='logo' className='sidebar__img' />
        </Link>
        <i
          onClick={() => closeSidebar()}
          className='fa fa-times'
          id='sidebarIcon'
          aria-hidden='true'
        />
      </div>

      <div className='sidebar__menu'>
        <div className='sidebar__link active_menu_link'>
          <i className='fa fa-industry'></i>
          <a href='#'>Dashbord Smart Industry</a>
        </div>
        <h2>My work</h2>
        <div className='sidebar__link'>
          <i className='fa  fa-tachometer' aria-hidden='true'></i>
          <Link to='/uap'>UAPs</Link>
        </div>
        <div className='sidebar__link'>
          <i className='fa  fa-cogs'></i>
          <Link to='/range'>Range</Link>
        </div>
        <div className='sidebar__link'>
          <i className='fa fa-id-badge'></i>
          <Link to='/personnel'>Personnel</Link>
        </div>
        <div className='sidebar__link'>
          <i className='fa  fa-line-chart'></i>
          <Link to='/uap'>Statistics</Link>
        </div>

        <h2>Report</h2>
        <div className='sidebar__link'>
          <i className='fa fa-file'></i>
          <Link to='/report/production'>Production Report</Link>
        </div>
        <div className='sidebar__link'>
          <i className='fa fa-table'></i>
          <a href='#'>KPI Report</a>
        </div>

        <h2>Subscribers</h2>
        <div className='sidebar__link'>
          <i className='fa fa-user-o'></i>
          <Link to={"/register"}>
            <a>User registration</a>
          </Link>
        </div>

        <div className='sidebar__link'>
          <i className='fa fa-users'></i>
          <Link to={"/usersList"}>
            <a>List of users</a>
          </Link>
        </div>

        <h2>
          <i className='fa fa-info-circle' aria-hidden='true' />
          <a>Help</a>
        </h2>
        <div className='sidebar__logout'>
          <i className='fa  fa-sign-out'></i>
          <a href='/login' onClick={logOut}>
            Log out
          </a>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
