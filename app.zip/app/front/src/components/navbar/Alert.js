/** @format */

import React, { useEffect, useState } from "react";
import { Input, InputNumber } from "antd";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { height } from "@mui/system";
import Production from "../uap/Production";

const Alert = () => {
  const { TextArea } = Input;
  const [show, setShow] = useState(false);

  // useEffect(() => {
  //   const interval = setInterval(() => {
  //     // console.log("This will run every second!");
  //     return (<div> hello!!! </div>), console.log("hello");
  //   }, 3000);
  //   return () => clearInterval(interval);
  // }, []);
  const day = new Date();
  let minute = day.getMinutes("mm");
  console.log(minute);
  // useEffect(() => {
  //   if (minute + "" === "59") {
  //     window.onload = function () {
  //       if (!window.location.hash) {
  //         window.location = window.location + "#loaded";
  //         window.location.reload();
  //       }
  //     };
  //     console.log(minute);
  //     setShow(true);
  //   }
  // }, [minute]);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  useEffect(() => {}, []);
  setInterval(() => {
    if (minute === 0) {
      setShow(true);
    }
  }, 30000);
  return (
    <div>
      <Button variant=' btn btn-outline-secondary' onClick={handleShow}>
        <i className='fa fa-bell' aria-hidden='true' /> Alert
      </Button>
      <Modal show={show} onHide={handleClose} id='myModal'>
        <Modal.Header closeButton>
          <Modal.Title>Hourly production notification</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Production />
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default Alert;
