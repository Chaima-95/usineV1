/** @format */
import React, { useState, useEffect } from "react";
 import "./Navbar.css";
import avatar from "../../assets/avatar.svg";

 
 
// import AuthVerify from "./common/AuthVerify";
import EventBus from "../../common/EventBus";
import Alert from "./Alert";
import authService from "../../services/auth.service";

const Navbar = ({ sidebarOpen, openSidebar }) => {
  const [showSuperadminBoard, setShowSuperadminBoard] = useState(false);
  const [showAdminBoard, setShowAdminBoard] = useState(false);
  const [currentUser, setCurrentUser] = useState(undefined);
  const [showProfile, setShowProfile] = useState(false);

 
    useEffect(() => {
      const user = authService.getCurrentUser();
      if (user) {
        setCurrentUser(user);
        setShowSuperadminBoard(user.roles.includes("ROLE_SUPERADMIN"));
        setShowAdminBoard(user.roles.includes("ROLE_ADMIN"));
      }
      EventBus.on("logout", () => {
        logOut();
      });
      return () => {
        EventBus.remove("logout");
      };
    }, []);

    const logOut = () => {
      authService.logout();
      setShowSuperadminBoard(false);
      setShowAdminBoard(false);
      setCurrentUser(undefined);
    };

  
  return (
    <nav className='navbar'>
      <div className='nav_icon' onClick={() => openSidebar()}>
        <i className='fa fa-bars' aria-hidden='true'></i>
      </div>

      <div className='navbar__left'>
        <a className='active_link' href='/home'>
          Home
        </a>
      </div>

      <div className='navbar__right'>
        <Alert />
        {/*<a href='#'>
          <i className='fa fa-bell' aria-hidden='true'></i>
  </a>**/}
        {currentUser && (
          <a href='/profile'>
            <img width='30' src={avatar} alt='avatar' />
          </a>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
