/** @format */

import React, { useState } from "react";
import { useEffect } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import planificationService from "../../services/planification.service";
import productionService from "../../services/production.service";

import personnelService from "../../services/personnel.service";
import aleaService from "../../services/alea.service";

const Production = () => {
  // form validation rules
  const validationSchema = Yup.object().shape({
    numberOfPersons: Yup.string().required("Number of persons is required"),
    productName: Yup.string().required("Nom du produit is required"),
    hour: Yup.string().required("Heure de saisie is required"),

    date: Yup.string().required("Date is required"),

    piecesProduced: Yup.string().required(
      "Nombre des pièces produites is required"
    ),

    nonConform: Yup.string().required(
      "Nombre des pièces non conformes is required"
    ),
    alea: Yup.string().required("alea  is required"),
    comment: Yup.string().required("Comentaire is required"),

    persons: Yup.array().of(
      Yup.object().shape({
        matricule: Yup.string().required("Matricule is required"),
      })
    ),
  });

  const formOptions = { resolver: yupResolver(validationSchema) };
  // functions to build form returned by useForm() and useFieldArray() hooks
  const { register, control, handleSubmit, reset, formState, watch } =
    useForm(formOptions);
  const { errors } = formState;
  const { fields, append, remove } = useFieldArray({
    name: "persons",
    control,
  });
  // watch to enable re-render when ticket number is changed
  const numberOfPersons = watch("numberOfPersons");

  const currentDate = new Date();
  const date = currentDate.toDateString();

  //*------GET ALL PRODUCTS */
  const [planification, setPlanification] = useState([]);
  const [personnels, setPersonnels] = useState([]);
  const [aleas, setAleas] = useState([]);

  const initialValues = {
    product: "",
    alea: "",
    hour: "",
    date: "",
    nbrOfPiecesProduicedInHour: 0,
    nbrOfNonConformPieces: 0,
    nbrOfPersons: "",
    comment: "",
    matricule: "",
  };

  const [values, setValues] = useState([initialValues]);
  // const [persArray, setPersArray] = useState([]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setValues({
      ...values,
      [id]: value,
    });
  };

  // const handleChangePersonel = (e) => {
  //   setPersArray((pers) => [...pers, e.target.value]);
  // };
  // console.log(persArray);

  const addProduction = () => {
    let planification = JSON.parse(values.product);
    // item = personnels =JSON.parse(values.matricule)
    productionService
      .add({
        productName: {
          _id: planification._id,
          lines: [
            {
              name:
                planification.item.product.phase.name +
                "-" +
                planification.item.name,
              _id: planification.item._id,
            },
          ],
        },
        // nbrOfPersons: values.nbrOfPersons,
        // personnels: [{ matricule: JSON.parse(values.matricule) }],
      })
      .then((res) => {
        console.log(res.data.data);
        console.log("success");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllProducts = () => {
    planificationService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setPlanification(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllPersonnels = () => {
    personnelService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setPersonnels(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllAleas = () => {
    aleaService
      .getAll()
      .then((res) => {
        //console.log(res.data.data);
        setAleas(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    // update field array when ticket number changed
    const newVal = parseInt(numberOfPersons || 0);
    const oldVal = fields.length;
    getAllProducts();
    getAllPersonnels();
    getAllAleas();
    if (newVal > oldVal) {
      // append tickets to field array
      for (let i = oldVal; i < newVal; i++) {
        append({ matricule: "" });
      }
    } else {
      // remove tickets from field array
      for (let i = oldVal; i > newVal; i--) {
        remove(i - 1);
      }
    }
  }, [numberOfPersons]);
  function onSubmit(data) {
    // display form data on success
    alert("SUCCESS!! :-)\n\n" + JSON.stringify(data, null, 4));
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className='card m-3'>
        <h5 className='card-header'>
          Veuillez entrer la production de l'heure {currentDate.getHours() - 1}h
          - {currentDate.getHours()}h de {date}
        </h5>
        <div className='card-body border-bottom'>
          {/* <select
            className={`form-control ${errors.alea ? "is-invalid" : ""}`}
            value={values.alea}
            onChange={handleChange}>
            <option value=''></option>
            {aleas.map((item, index) => {
              return (
                <option value={JSON.stringify(item.name)} key={index}>
                  {item.name}
                </option>
              );
            })}
          </select> */}

          <label>Nom du produit</label>
          <select
            id='product'
            className='form-control'
            onChange={handleChange}
            value={values.product}
            // onChange={(e) => (
            //   setproductName(e.target.value), console.log(productName)
            // )}
          >
            <option value=''></option>
            {planification.map((plan, i) =>
              plan.lines.map((item, index) => (
                <option
                  value={JSON.stringify({ _id: plan._id, item })}
                  key={index}>
                  {item.product.phase.name} - {item.name}
                </option>
              ))
            )}
          </select>
          <label>Heure du saisie</label>
          <select
            defaultValue={currentDate.getHours()}
            className='form-control'
            id='hour'
            value={values.hour}
            onChange={handleChange}>
            {[
              "",
              1,
              2,
              3,
              4,
              5,
              6,
              7,
              8,
              9,
              10,
              11,
              12,
              13,
              14,
              15,
              16,
              17,
              18,
              19,
              20,
              21,
              22,
              23,
            ].map((i) => (
              <option key={i} value={i}>
                {i}
              </option>
            ))}
          </select>
          <label>Date</label>
          <input
            value={values.date}
            className='form-control'
            type='date'
            id='date'
            onChange={handleChange}
          />
          <label>Nombre des pièces produite</label>
          <input
            value={values.nbrOfPiecesProduicedInHour}
            className='form-control'
            type='number'
            id='nbrOfPieces'
            onChange={handleChange}
          />
          <label>Nombre des personnes</label>

          {/** -------------------------  nbr of persons -------------------------------------*/}
          <input
            value={values.nbrOfPersons}
            // onChange={handleChange}
            className={`form-control ${
              errors.numberOfPersons ? "is-invalid" : ""
            }`}
            id='nbrOfPersons'
            {...register("numberOfPersons")}
            type='number'
          />
          {/* <select
            value={values.nbrOfPersons}
            onChange={handleChange}
            id='nbrOfPersons'
            {...register("numberOfPersons")}
            className={`form-control ${
              errors.numberOfPersons ? "is-invalid" : ""
            }`}>
            {["", 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
              <option key={i} value={i}>
                {i}
              </option>
            ))}
          </select> */}
          <div className='invalid-feedback'>
            {errors.numberOfPersons?.message}
          </div>
          {fields.map((item, i) => (
            <div key={item.id} className='list-group list-group-flush'>
              <h5>Matricule {i + 1}</h5>
              <select
                // value={values.matricule}
                // onChange={handleChange}
                className={`form-control ${
                  errors.persons?.[i]?.matricule ? "is-invalid" : ""
                }`}
                id={`matricule[${i}]`}
                // name={`persons[${i}]matricule`}
                {...register(`matricule.${i}`)}
                type='text'>
                {personnels.map((item, index) => {
                  return (
                    // console.log(JSON.stringify(item.matricule)),
                    <option value={JSON.stringify(item)} key={index}>
                      {item.matricule}
                    </option>
                  );
                })}
              </select>
              {/* <div className='invalid-feedback'>
                {errors.persons?.[i]?.matricule?.message}
              </div> */}
            </div>
          ))}
          <label>Nombre des pièces non conformes</label>
          <input
            value={values.nbrOfNonConformPieces}
            onChange={handleChange}
            className='form-control'
            type='number'
            id='nbrOfnonConformPieces'
          />
          <label>Alea</label>
          <select
            className={`form-control ${errors.alea ? "is-invalid" : ""}`}
            value={values.alea}
            onChange={handleChange}>
            <option value=''></option>
            {aleas.map((item, index) => {
              return (
                <option value={JSON.stringify(item.name)} key={index}>
                  {item.name}
                </option>
              );
            })}
          </select>
          {/* <div className='invalid-feedback'>{errors.alea?.message}</div> */}

          <label>Commentaire</label>
          <textArea
            value={values.comment}
            className='form-control'
            id='comment'
            onChange={handleChange}
          />
        </div>

        <div className='card-footer text-center border-top-0'>
          <button onClick={addProduction} className='btn btn-primary mr-1'>
            Enregistrer
          </button>
          <button
            onClick={() => reset()}
            type='button'
            className='btn btn-secondary mr-1'>
            Reset
          </button>
        </div>
      </div>
    </form>
  );
};

export default Production;
