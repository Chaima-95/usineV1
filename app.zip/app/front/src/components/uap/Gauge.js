/** @format */

import React, { useEffect, useState } from "react";
import ReactSpeedometer from "react-d3-speedometer";
import Lights from "./Lights";

const Gauge = (props) => {
  const [value, setValue] = useState(0);

  const getAll = () => {
    setValue(50);
  };
  useEffect(() => {
    getAll();
  }, [value]);
  return (
    <>
      <ReactSpeedometer
        width={190}
        needleHeightRatio={0.8}
        customSegmentStops={[0, 20, 40, 60, 80, 100]}
        segmentColors={["red", "red", "red", "yellow", "#01D201"]}
        ringWidth={14}
        height={190}
        value={props.value}
        needleColor='black'
        maxValue={100}
        currentValueText='#{value}'
        currentValuePlaceholderStyle={"#{value}"}
      />
      <Lights value={props.value} />
    </>
  );
};
export default Gauge;
