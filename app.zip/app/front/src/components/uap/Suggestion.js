/** @format */

import React from "react";

const Suggestion = ({ searchWord }) => {
  const [filtredArray, setfiltredArray] = useState([]);
  useEffect(() => {
    switch (currentInput) {
      case "zoneName":
        zoneService
          .getFiltredZones(searchWord)
          .then((res) => setfiltredArray(res.data.data));
        break;

      default:
        break;
    }
  }, [searchWord]);
  return (
    <div>
      {filtredArray &&
        filtredArray.map((item, index) => (
          <div
            className='suggestion justify-content-md-center'
            key={i}
            onClick={() => {
              onSuggestHandler(zonename.name);
            }}>
            {zonename.name}
          </div>
        ))}
    </div>
  );
};

export default Suggestion;
