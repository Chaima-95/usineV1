/** @format */

import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import { Link } from "react-router-dom";
import Gauge from "../Gauge";
import Header from "../Header";
import Machines from "./Machines";
import "./uapList.css";
const Uap = () => {
  const uapList = [
    "Insertion",
    "CMS",
    "Retouche",
    "Emballage",
    "fail",
    "test1",
  ];
  const [machineButton, setmachineButton] = useState(false);
  const showChartMachine = () => {
    setmachineButton(true);
  };

  return (
    <>
      {machineButton ? (
        <Machines />
      ) : (
        <div className='uap_background'>
          <div className='container'>
            <div className='row uap_content '>
              <div className='col-md uaplistTilte'>
                <h5>UAP's list</h5>
              </div>
            </div>
            <div className='row uap_content'>
              {uapList.map((item, index) => (
                <div className='col-md-4 uap_card ' key={index}>
                  <h6>{item}</h6>
                  <Gauge />
                  <div className='buttons'>
                    <button className='btn btn-outline-primary indicators_buttons '>
                      EEO
                    </button>
                    <button className='btn btn-outline-primary indicators_buttons '>
                      TRS
                    </button>
                    <button className='btn btn-outline-primary indicators_buttons'>
                      TAP
                    </button>
                  </div>
                  <button
                    onClick={showChartMachine}
                    type='button'
                    className='btn btn-primary machine_button'>
                    Machines
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Uap;
