/** @format */

import React, { useState } from "react";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import "./machine.css";
import Uap from "./Uap";

const Machines = () => {
  const today = new Date();
  const date =
    today.getFullYear() + "/" + (today.getMonth() + 1) + "/" + today.getDate();
  const data = [
    {
      name: "Page A",
      uv: 4000,
      pv: 2400,
      amt: 2400,
    },
    {
      name: "Page B",
      uv: 3000,
      pv: 1398,
      amt: 2210,
    },
    {
      name: "Page C",
      uv: 2000,
      pv: 9800,
      amt: 2290,
    },
    {
      name: "Page D",
      uv: 2780,
      pv: 3908,
      amt: 2000,
    },
    {
      name: "Page E",
      uv: 1890,
      pv: 4800,
      amt: 2181,
    },
    {
      name: "Page F",
      uv: 2390,
      pv: 3800,
      amt: 2500,
    },
    {
      name: "Page G",
      uv: 3490,
      pv: 4300,
      amt: 2100,
    },
  ];
  const [backButton, setBackButton] = useState(false);
  const showBackPage = () => {
    setBackButton(true);
  };
  return (
    <>
      {backButton ? (
        <Uap />
      ) : (
        <div className='container machines_container'>
          <div className='row machine_title'>
            <button onClick={showBackPage}>Back</button>

            <div className='col-md'>
              <h6>DOWNS & STATISTICS</h6>
            </div>
            <div className='date_container'>{date}</div>
          </div>

          <div className='row'>
            <ResponsiveContainer width='100%' height='100%'>
              <div className='col-md'>
                <BarChart
                  width={500}
                  height={300}
                  data={data}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}>
                  <CartesianGrid strokeDasharray='3 3' />
                  <XAxis dataKey='name' />
                  <YAxis />
                  <Legend />
                  <Bar dataKey='pv' fill='red'>
                    <Tooltip />
                  </Bar>
                </BarChart>
              </div>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </>
  );
};

export default Machines;
