/** @format */

import React, { useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const Bottom = () => {
  const data = [
    {
      name: "Insertion",
      uv: 3501,
      pv: 150,
    },
    {
      name: "Retouche",
      uv: 2331,
      pv: 1398,
    },
    {
      name: "CMS",
      uv: 1120,
      pv: 12850,
    },
    {
      name: "injecton",
      uv: 220,
      pv: 850,
    },
    {
      name: "emballage",
      uv: 100,
      pv: 556,
    },
  ];

  const indicators = ["EEO", "TRS", "TAP"];
  return (
    <div className='container bottom_container'>
      <div className='row indicators'>
        {indicators.map((item) => (
          <div className='col-md gauge_container'>
            <h6>{item}</h6>
            <BarChart width={306} height={250} data={data}>
              <XAxis dataKey='name' />
              <YAxis />
              <Tooltip />
              <Bar dataKey='pv' fill='#3481F1' />
            </BarChart>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Bottom;
