/** @format */

import React, { useState, useEffect } from "react";
import Gauge from "../../../components/uap/Gauge";
import planService from "../../../services/planification.service";

import { Area, AreaChart, Tooltip, XAxis, YAxis } from "recharts";
import "../uap.css";

const Center = () => {
  const [toggleChart1, settoggleChart1] = useState(true);
  const [toggleChart2, settoggleChart2] = useState(false);

  const [toggleChart3, settoggleChart3] = useState(true);
  const [toggleChart4, settoggleChart4] = useState(false);

  const [toggleChart5, settoggleChart5] = useState(true);
  const [toggleChart6, settoggleChart6] = useState(false);

  const showChart1 = () => {
    settoggleChart1(true);
    settoggleChart2(false);
  };
  const showChart2 = () => {
    settoggleChart1(false);
    settoggleChart2(true);
  };

  const showChart3 = () => {
    settoggleChart3(true);
    settoggleChart4(false);
  };
  const showChart4 = () => {
    settoggleChart3(false);
    settoggleChart4(true);
  };

  const showChart5 = () => {
    settoggleChart5(true);
    settoggleChart6(false);
  };
  const showChart6 = () => {
    settoggleChart5(false);
    settoggleChart6(true);
  };
  const [plans, setPlans] = useState([]);
  const getAllplans = () => {
    planService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setPlans(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    getAllplans();
  }, []);

  const data = [
    {
      name: "Insertion",
      uv: 4000,
      pv: 2400,
    },
    {
      name: "Retouche",
      uv: 3000,
      pv: 1398,
    },
    {
      name: "CMS",
      uv: 2000,
      pv: 12850,
    },
  ];

  return (
    <div className='container'>
      <h5 className='uap_title'>Indicateur de performance industrielle</h5>
      <div className='row indicators'>
        <div className='col-md gauge_container'>
          <h6 className='sub_title'>EEO</h6>
          {toggleChart1 && <Gauge value='46' />}
          {toggleChart2 && (
            <AreaChart width={320} height={180} data={data}>
              <XAxis dataKey='name' />
              <YAxis />
              <Tooltip />
              <Area
                type='monotone'
                dataKey='uv'
                stroke='#3481F1'
                fill='#3481F1'
                fillOpacity={0.3}
              />
            </AreaChart>
          )}
          <div className='gauge_buttons'>
            <button
              className='btn btn-outline-primary outline'
              onClick={showChart1}>
              <i className='fa fa-circle-o-notch' aria-hidden='true' />
            </button>
            <button
              className='btn btn-outline-primary outline'
              onClick={showChart2}>
              <i className='fa fa-line-chart' aria-hidden='true'></i>
            </button>
          </div>
        </div>

        <div className='col-md gauge_container'>
          <h6 className='sub_title'>TRS</h6>
          {toggleChart3 && <Gauge value='61' />}
          {toggleChart4 && (
            <AreaChart width={320} height={180} data={data}>
              <XAxis dataKey='name' />
              <YAxis />
              <Tooltip />
              <Area
                type='monotone'
                dataKey='uv'
                stroke='#99EE5F'
                fill='#99EE5F'
                fillOpacity={0.3}
              />
            </AreaChart>
          )}
          <div className='gauge_buttons'>
            <button
              className=' btn btn-outline-primary outline'
              onClick={showChart3}>
              <i className='fa fa-circle-o-notch' aria-hidden='true' />
            </button>
            <button
              className='btn btn-outline-primary outline'
              onClick={showChart4}>
              <i className='fa fa-line-chart' aria-hidden='true'></i>
            </button>
          </div>
        </div>
        <div className='col-md gauge_container'>
          <h6 className='sub_title'>TAP</h6>
          {toggleChart5 && <Gauge value='90' />}
          {toggleChart6 && (
            <AreaChart data={data} width={320} height={180}>
              <XAxis dataKey='name' />
              <YAxis />
              <Tooltip />
              <Area
                type='monotone'
                dataKey='uv'
                stroke='#F4B72B'
                fill='#F4B72B'
                fillOpacity={0.3}
              />
            </AreaChart>
          )}
          <div className='gauge_buttons'>
            <button
              className=' btn btn-outline-primary outline'
              onClick={showChart5}>
              <i className='fa fa-circle-o-notch' aria-hidden='true' />
            </button>
            <button
              className='btn btn-outline-primary outline'
              onClick={showChart6}>
              <i className='fa fa-line-chart' aria-hidden='true'></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Center;
