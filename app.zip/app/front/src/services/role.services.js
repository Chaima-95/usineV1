/** @format */

import Axios from "axios";

const API_URL = "http://localhost:8082/api/roles";

const role = (id) => {
  return Axios.get(API_URL + "/" + id);
};
const allroles = () => {
  return Axios.get(API_URL + "/");
};

export default {
  role,
  allroles,
};
