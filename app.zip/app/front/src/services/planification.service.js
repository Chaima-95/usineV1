/** @format */
import axios from "axios";
import authHeader from "./auth-header";
const API_URL = "http://localhost:8082/api/planification";

const getAll = () => {
  return axios.get(`${API_URL}/getall`);
};

const add = (data) => {
  return axios.post(API_URL + `/create/`, data);
};

const get = (id) => {
  return axios.get(`/${id}`, { headers: authHeader() });
};

const update = (id, data) => {
  return axios.put(API_URL + `/update/${id}`, data);
};
const remove = (id) => {
  return axios.delete(API_URL + `/delete/${id}`);
};

export default {
  getAll,
  add,
  remove,
  update,
  get,
};
