/** @format */

import React, { useRef } from "react";

import { Button } from "@progress/kendo-react-buttons";
import { PDFExport, savePDF } from "@progress/kendo-react-pdf";

import "./report.css";
const ProdReport = () => {
  const pdfExportComponent = useRef(null);
  // const handleExportWithComponent = (e) => {
  //   pdfExportComponent.current.save();
  // };
  const handleExportWithMethod = (e) => {
    let element = document.querySelector(".k-grid") || document.body;
    savePDF(element, {
      paperSize: "A4",
    });
    // pdfExportComponent.current.savePDF();
  };
  return (
    <div className='container report_container'>
      <div className='row uap_content report_row'>
        <div className='col-md uaplistTilte'>
          <h5>Production Report & Alea</h5>
        </div>
      </div>
      <PDFExport ref={pdfExportComponent} paperSize='A4'>
        <div className='row uap_content'>
          <div className='col-md'>
            <h6>Could you choose</h6>
          </div>
        </div>
        <Button primary={true}> ButtonComponent</Button>
        <Button primary={true} onClick={handleExportWithMethod}>
          {" "}
          ButtonMethod
        </Button>
      </PDFExport>
    </div>
  );
};

export default ProdReport;
