/** @format */

import React, { useState } from "react";
import GeneralVue from "../../components/uap/generalVue/GeneralVue";
import Header from "../../components/uap/Header";

const Uap = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default Uap;
