/** @format */

import React, { useState, useRef } from "react";
import Form from "react-validation/build/form";
import Input from "react-validation/build/input";
import CheckButton from "react-validation/build/button";
import { isEmail } from "validator";
import AuthService from "../../services/auth.service";

import "./register.css";
import UserRegistration from "./UserRegistration";
import AdminRegistration from "./AdminRegistration";

const Register = (props) => {
  // const AdminRegistration = (e) => {
  //   e.preventDefault();
  //   setMessage("");
  //   setSuccessful(false);
  //   form.current.validateAll();
  //   console.log(confirm, password);
  //   if (checkBtn.current.context._errors.length === 0) {
  //     AuthService.register(email, password, "admin").then(
  //       (response) => {
  //         setMessage(response.data.message);
  //         setSuccessful(true);
  //       },
  //       (error) => {
  //         const resMessage =
  //           (error.response &&
  //             error.response.data &&
  //             error.response.data.message) ||
  //           error.message ||
  //           error.toString();
  //         setMessage(resMessage);
  //         setSuccessful(false);
  //       }
  //     );
  //   } else {
  //     console.log("pass doesnt match!!");
  //   }
  // };
  return (
    <div className='register_container'>
      <div className='row'>
        <div className='title col-lg-12'>
          <h5>Accessible subscribers </h5>
          <p> global administrator</p>
        </div>
      </div>
      <div className='row'>
        <div className='user_register col-md-6'>
          <UserRegistration />
        </div>
        <div className='admin_register col-md-6'>
          <AdminRegistration />
        </div>
      </div>
    </div>
  );
};
export default Register;
